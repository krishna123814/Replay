package com.example.simplebrowser

import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.provider.Settings
import android.text.InputType
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import kotlin.math.abs

/**
 * Lion floating browser: kisi bhi app ke upar tairta golden dot.
 * - dot tap -> browser window show/hide; dot long-press -> chhota pill menu (back, refresh, maximize, window show/hide, settings, close); drag -> move
 * - dot ko kahin bhi drag karo; neeche ❌ zone me chhodo to band
 * - browser window: upar ke handle se drag, ◢ se resize, ⛶ maximize
 * - ⚙ settings: URL, icon size, opacity, dot size
 * - text select -> Lion Copy bar (Copy / Select all / Paste)
 * - <input type=file> ke liye file picker, JS prompt, fullscreen video
 */
class FloatingService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.simplebrowser.STOP_FLOATING"
        const val ACTION_UPDATE = "com.example.simplebrowser.UPDATE_NOW"
        const val CHANNEL_ID = "floating_browser"
        const val NOTIF_ID = 1101
        const val PREFS = "FloatingAppPrefs"

        // File picker (input type=file) ka result yahan hold hota hai
        var filePathCallback: ValueCallback<Array<Uri>>? = null
        var instance: FloatingService? = null
    }

    private var floatWindow: FloatWindow? = null

    // update download progress (0..99), -1 = download nahi chal raha
    private var downloadPercent = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        goForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        createWindowIfNeeded()

        // 6 ghante me max ek baar naya version dekho
        if (UpdateChecker.shouldAutoCheck(this)) {
            UpdateChecker.check(this) { info -> if (info != null) onUpdateFound(info) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        createWindowIfNeeded()
        if (intent?.action == ACTION_UPDATE) {
            val p = UpdateChecker.pending
            if (p != null) {
                startUpdate(p)
            } else {
                UpdateChecker.check(this) { info ->
                    if (info != null) {
                        UpdateChecker.pending = info
                        startUpdate(info)
                    } else {
                        Toast.makeText(this, "Lion up to date", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        floatWindow?.destroy()
        floatWindow = null
        instance = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    fun restartWindow() {
        floatWindow?.destroy()
        floatWindow = null
        createWindowIfNeeded()
    }

    private fun createWindowIfNeeded() {
        if (floatWindow != null) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val url = prefs.getString("custom_url", AppConfig.DEFAULT_URL) ?: AppConfig.DEFAULT_URL
        val w = FloatWindow(this, url)
        floatWindow = w
        w.show()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Lion", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val stop = Intent(this, FloatingService::class.java).setAction(ACTION_STOP)
        val stopPi = PendingIntent.getService(
            this, 0, stop, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = Intent(this, MainActivity::class.java)
        val openPi = PendingIntent.getActivity(
            this, 1, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val installIntent = UpdateChecker.readyInstallIntent
        val hasPending = UpdateChecker.pending != null
        val text = when {
            downloadPercent in 0..99 -> "Update download ho raha hai: $downloadPercent%"
            installIntent != null -> "Update download ho gaya – \"Install karo\" dabao"
            hasPending -> "Naya version available"
            else -> "Band karne ke liye \"Band karo\" dabao"
        }
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif_lion)
            .setContentTitle("Lion chal raha hai")
            .setContentText(text)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Band karo", stopPi)
            .setOngoing(true)
        if (installIntent != null) {
            val installPi = PendingIntent.getActivity(
                this, 3, installIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(android.R.drawable.stat_sys_download_done, "Install karo", installPi)
        } else if (hasPending && downloadPercent < 0) {
            val upd = Intent(this, FloatingService::class.java).setAction(ACTION_UPDATE)
            val updPi = PendingIntent.getService(
                this, 2, upd, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(android.R.drawable.stat_sys_download, "Update karo", updPi)
        }
        return b.build()
    }

    private fun refreshNotification() {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (e: Exception) {
        }
    }

    // ── in-app update ─────────────────────────────────────────────────────
    private fun onUpdateFound(info: UpdateChecker.Info) {
        if (instance == null) return
        UpdateChecker.pending = info
        Toast.makeText(this, "Lion update available (tap notification)", Toast.LENGTH_LONG).show()
        refreshNotification()
    }

    private fun startUpdate(info: UpdateChecker.Info) {
        if (!UpdateChecker.ensureInstallPermission(this)) return
        Toast.makeText(this, "Download ho raha hai…", Toast.LENGTH_SHORT).show()
        downloadPercent = 0
        refreshNotification()
        UpdateChecker.downloadAndInstall(
            this, info,
            onProgress = { pct ->
                if (pct >= 100) {
                    downloadPercent = -1
                    refreshNotification()
                } else if (pct % 5 == 0 && pct != downloadPercent) {
                    downloadPercent = pct
                    refreshNotification()
                }
            },
            onError = { msg ->
                downloadPercent = -1
                refreshNotification()
                Toast.makeText(this, "Update nahi ho paya: $msg", Toast.LENGTH_LONG).show()
            },
            onInstallFailed = {
                // install screen seedha nahi khuli -> notification me "Install karo" action
                refreshNotification()
                Toast.makeText(this, "Notification me \"Install karo\" dabao", Toast.LENGTH_LONG).show()
            }
        )
    }

    private fun goForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    inner class FloatWindow(private val ctx: Context, private var url: String) {

        private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        private val density = ctx.resources.displayMetrics.density
        private val handler = Handler(Looper.getMainLooper())

        // ── Window B: browser ─────────────────────────────────────────────
        private lateinit var root: FrameLayout
        private lateinit var layoutFull: FrameLayout
        private lateinit var content: LinearLayout
        private lateinit var dragHandle: FrameLayout
        private lateinit var webView: WebView
        private lateinit var layoutSettings: ScrollView
        private lateinit var resizeCorner: TextView
        private lateinit var copyBar: LinearLayout
        private lateinit var params: WindowManager.LayoutParams

        // ── Window A: dot + pill ──────────────────────────────────────────
        private lateinit var dotRoot: LinearLayout
        private lateinit var dotWrapper: FrameLayout
        private lateinit var dotView: View
        private lateinit var pill: LinearLayout
        private lateinit var dotParams: WindowManager.LayoutParams

        // ── close zone (dot drag ke waqt) ─────────────────────────────────
        private lateinit var closeZone: FrameLayout
        private lateinit var closeParams: WindowManager.LayoutParams

        private lateinit var btnBack: TextView
        private lateinit var btnRefresh: TextView
        private lateinit var btnMaximize: TextView
        private lateinit var btnWindow: TextView
        private lateinit var btnSettings: TextView
        private lateinit var btnClose: TextView

        private lateinit var inputUrl: EditText
        private lateinit var sbSize: SeekBar
        private lateinit var sbOpacity: SeekBar
        private lateinit var sbDotSize: SeekBar

        private val menuButtons = ArrayList<TextView>()

        private var isMaximized = false
        private var isBrowserShown = false
        private var isPillOpen = false
        private var pillOnLeft = false
        private var isCloseZoneVisible = false

        private var customView: View? = null
        private var customViewCallback: WebChromeClient.CustomViewCallback? = null
        private var wasMaximizedByJS = false

        // Copy bar state
        private var lastSelection = ""
        private var editFocused = false

        // dot ka center (screen pixels)
        private var dotCX = 0
        private var dotCY = 0
        private var lastWindowX = 0
        private var lastWindowY = 0
        private var normalW = 0
        private var normalH = 0

        private val collapseRunnable = Runnable { closePill() }

        // dot long-press: pill menu kholo (haptic ke saath)
        private var longPressed = false
        private val longPressRunnable = Runnable {
            longPressed = true
            dotWrapper.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (isPillOpen) scheduleAutoCollapse() else openPill()
        }

        private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

        @Suppress("DEPRECATION")
        private fun overlayType(): Int =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE

        // ── entry ─────────────────────────────────────────────────────────
        fun show() {
            val m = ctx.resources.displayMetrics
            lastWindowX = dp(8)
            lastWindowY = dp(60)
            // default: right edge, screen height ka 1/4
            dotCX = prefs.getInt("dot_x", m.widthPixels - dp(24))
            dotCY = prefs.getInt("dot_y", m.heightPixels / 4)
            dotCX = dotCX.coerceIn(0, m.widthPixels)
            dotCY = dotCY.coerceIn(0, m.heightPixels)

            buildUi()
            setupWindowParams()
            setupControls()
            setupWebView()
            loadSavedSettings()

            // pehle browser window (hidden), phir dot -> dot hamesha upar rahe
            wm.addView(root, params)
            wm.addView(dotRoot, dotParams)
            webView.loadUrl(url)
        }

        fun destroy() {
            handler.removeCallbacksAndMessages(null)
            try { CookieManager.getInstance().flush() } catch (e: Exception) { }
            if (isCloseZoneVisible) {
                try { wm.removeView(closeZone) } catch (e: Exception) { }
                isCloseZoneVisible = false
            }
            try { wm.removeView(dotRoot) } catch (e: Exception) { }
            try { wm.removeView(root) } catch (e: Exception) { }
            try { webView.destroy() } catch (e: Exception) { }
        }

        // ── UI (code se banta hai, XML ki zaroorat nahi) ───────────────────
        private fun mkBtn(label: String): TextView {
            val t = TextView(ctx)
            t.text = label
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.textSize = 14f
            t.layoutParams = LinearLayout.LayoutParams(dp(32), dp(32))
            menuButtons.add(t)
            return t
        }

        private fun buildUi() {
            // ---------- Window B: browser ----------
            root = FrameLayout(ctx)
            root.visibility = View.GONE

            layoutFull = FrameLayout(ctx)
            layoutFull.setBackgroundColor(Color.parseColor("#131722"))

            content = LinearLayout(ctx)
            content.orientation = LinearLayout.VERTICAL

            // upar patla drag handle (horizontal, vertical side patti nahi)
            dragHandle = FrameLayout(ctx)
            dragHandle.setBackgroundColor(Color.parseColor("#1e222d"))
            val grip = View(ctx)
            val gripShape = GradientDrawable()
            gripShape.shape = GradientDrawable.RECTANGLE
            gripShape.cornerRadius = dp(2).toFloat()
            gripShape.setColor(Color.parseColor("#88FFFFFF"))
            grip.background = gripShape
            dragHandle.addView(grip, FrameLayout.LayoutParams(dp(36), dp(4), Gravity.CENTER))

            webView = WebView(ctx)

            content.addView(dragHandle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)))
            content.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            layoutFull.addView(
                content,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )

            resizeCorner = TextView(ctx)
            resizeCorner.text = "◢"
            resizeCorner.setTextColor(Color.parseColor("#CCFFFFFF"))
            resizeCorner.setBackgroundColor(Color.parseColor("#66000000"))
            resizeCorner.gravity = Gravity.CENTER
            resizeCorner.textSize = 14f
            layoutFull.addView(
                resizeCorner,
                FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.END)
            )

            buildCopyBar()
            layoutFull.addView(
                copyBar,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                ).also { it.bottomMargin = dp(32) }
            )

            buildSettings()
            layoutFull.addView(
                layoutSettings,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )

            root.addView(
                layoutFull,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )

            // ---------- Window A: dot + pill ----------
            dotRoot = LinearLayout(ctx)
            dotRoot.orientation = LinearLayout.HORIZONTAL
            dotRoot.gravity = Gravity.CENTER_VERTICAL

            dotWrapper = FrameLayout(ctx)
            dotView = View(ctx)
            val dotShape = GradientDrawable()
            dotShape.shape = GradientDrawable.OVAL
            dotShape.setColor(Color.parseColor("#F5A623"))
            dotShape.setStroke(maxOf(1, (1.5f * density).toInt()), Color.parseColor("#B3FFFFFF"))
            dotView.background = dotShape
            dotWrapper.addView(dotView, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
            dotRoot.addView(dotWrapper, LinearLayout.LayoutParams(dp(40), dp(40)))

            // pill: dark rounded row, dot ke paas khulta hai
            pill = LinearLayout(ctx)
            pill.orientation = LinearLayout.HORIZONTAL
            pill.gravity = Gravity.CENTER
            pill.setPadding(dp(4), dp(4), dp(4), dp(4))
            val pillShape = GradientDrawable()
            pillShape.shape = GradientDrawable.RECTANGLE
            pillShape.cornerRadius = dp(20).toFloat()
            pillShape.setColor(Color.parseColor("#F21e222d")) // ~0.95 alpha
            pill.background = pillShape

            btnBack = mkBtn("◀")
            btnRefresh = mkBtn("⟳")
            btnMaximize = mkBtn("⛶")
            btnWindow = mkBtn("🪟")
            btnSettings = mkBtn("⚙")
            btnClose = mkBtn("✕")
            for (b in menuButtons) pill.addView(b)

            // close zone (alag overlay window, dot drag ke waqt dikhta hai)
            closeZone = FrameLayout(ctx)
            val cross = TextView(ctx)
            cross.text = "❌"
            cross.textSize = 26f
            cross.gravity = Gravity.CENTER
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.parseColor("#CCFF3333"))
            closeZone.background = bg
            closeZone.addView(cross, FrameLayout.LayoutParams(dp(65), dp(65), Gravity.CENTER))
            closeParams = WindowManager.LayoutParams(
                dp(65), dp(65), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
            )
            closeParams.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            closeParams.y = dp(40)
        }

        // ── Copy bar (Copy / Select all / Paste) ──────────────────────────
        private fun copyBtn(text: String, onTap: () -> Unit): TextView {
            val t = TextView(ctx)
            t.text = text
            t.setTextColor(Color.WHITE)
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.setOnClickListener { onTap() }
            return t
        }

        private fun buildCopyBar() {
            copyBar = LinearLayout(ctx)
            copyBar.orientation = LinearLayout.HORIZONTAL
            copyBar.gravity = Gravity.CENTER
            copyBar.isClickable = true
            copyBar.visibility = View.GONE
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.cornerRadius = dp(20).toFloat()
            shape.setColor(Color.parseColor("#F21e222d"))
            shape.setStroke(dp(1), Color.parseColor("#55FFFFFF"))
            copyBar.background = shape
            copyBar.addView(copyBtn("Copy") { doCopy() })
            copyBar.addView(copyBtn("Select all") { doSelectAll() })
            copyBar.addView(copyBtn("Paste") { doPaste() })
        }

        private fun updateCopyBar() {
            copyBar.visibility =
                if (lastSelection.isNotBlank() || editFocused) View.VISIBLE else View.GONE
        }

        private fun doCopy() {
            if (lastSelection.isBlank()) {
                Toast.makeText(ctx, "Pehle text select karo", Toast.LENGTH_SHORT).show()
                return
            }
            try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Lion", lastSelection))
                Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Copy nahi ho paya", Toast.LENGTH_SHORT).show()
                return
            }
            webView.evaluateJavascript(
                "(function(){var a=document.activeElement;" +
                    "if(a&&(a.tagName==='TEXTAREA'||a.tagName==='INPUT')&&typeof a.selectionStart==='number'){a.selectionEnd=a.selectionStart;}" +
                    "window.getSelection().removeAllRanges();})()",
                null
            )
            lastSelection = ""
            updateCopyBar()
        }

        private fun doSelectAll() {
            webView.requestFocus()
            webView.evaluateJavascript("document.execCommand('selectAll')", null)
        }

        private fun doPaste() {
            val text: String? = try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(ctx)?.toString() else null
            } catch (e: Exception) {
                null
            }
            if (text.isNullOrEmpty()) {
                Toast.makeText(ctx, "Clipboard khali/blocked", Toast.LENGTH_SHORT).show()
                return
            }
            webView.requestFocus()
            webView.evaluateJavascript(
                "document.execCommand('insertText', false, " + JSONObject.quote(text) + ")",
                null
            )
        }

        // JS -> Kotlin: selection / input focus ki khabar
        inner class Bridge {
            @JavascriptInterface
            fun onState(text: String?, editable: Boolean) {
                handler.post {
                    lastSelection = text ?: ""
                    editFocused = editable
                    updateCopyBar()
                }
            }
        }

        private val selectionJs = """
            (function () {
              if (window.__lionSel) return;
              window.__lionSel = true;
              function isEd(el) {
                if (!el) return false;
                var t = el.tagName;
                return t === 'TEXTAREA' || t === 'INPUT' || el.isContentEditable === true;
              }
              function sel() {
                var t = '';
                var a = document.activeElement;
                try {
                  if (a && (a.tagName === 'TEXTAREA' || a.tagName === 'INPUT') && typeof a.selectionStart === 'number') {
                    t = String(a.value).substring(a.selectionStart, a.selectionEnd);
                  }
                } catch (e) {}
                if (!t) t = String(window.getSelection());
                return t;
              }
              function push() {
                try { LionBridge.onState(sel(), isEd(document.activeElement)); } catch (e) {}
              }
              document.addEventListener('selectionchange', push);
              document.addEventListener('focusin', push);
              document.addEventListener('focusout', function () { setTimeout(push, 50); });
              document.addEventListener('keyup', push);
              document.addEventListener('touchend', function () { setTimeout(push, 50); });
            })();
        """.trimIndent()

        private fun label(text: String): TextView {
            val t = TextView(ctx)
            t.text = text
            t.setTextColor(Color.parseColor("#d1d4dc"))
            t.textSize = 13f
            t.setPadding(0, dp(12), 0, dp(2))
            return t
        }

        private fun blueButton(text: String): Button {
            val b = Button(ctx)
            b.text = text
            b.setTextColor(Color.WHITE)
            b.setBackgroundColor(Color.parseColor("#2962ff"))
            return b
        }

        private fun buildSettings() {
            layoutSettings = ScrollView(ctx)
            layoutSettings.setBackgroundColor(Color.parseColor("#F01e222d"))
            layoutSettings.visibility = View.GONE

            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(14), dp(14), dp(14), dp(14))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            col.addView(label("Website URL"), lp)
            inputUrl = EditText(ctx)
            inputUrl.setTextColor(Color.WHITE)
            inputUrl.textSize = 13f
            inputUrl.setSingleLine(true)
            inputUrl.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            col.addView(inputUrl, lp)

            val saveBtn = blueButton("Save URL aur load karo")
            saveBtn.setOnClickListener {
                var newUrl = inputUrl.text.toString().trim()
                if (newUrl.isNotEmpty()) {
                    if (!newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
                        val ipPort = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")
                        newUrl = if (ipPort.matches(newUrl)) "http://$newUrl" else "https://$newUrl"
                    }
                    prefs.edit().putString("custom_url", newUrl).apply()
                    url = newUrl
                    webView.loadUrl(url)
                    layoutSettings.visibility = View.GONE
                }
            }
            col.addView(saveBtn, lp)

            col.addView(label("Icon size"), lp)
            sbSize = SeekBar(ctx)
            sbSize.max = 10
            col.addView(sbSize, lp)

            col.addView(label("Dot opacity"), lp)
            sbOpacity = SeekBar(ctx)
            sbOpacity.max = 100
            col.addView(sbOpacity, lp)

            col.addView(label("Dot size (10–28dp)"), lp)
            sbDotSize = SeekBar(ctx)
            sbDotSize.max = 18 // progress 0..18 -> 10..28dp
            col.addView(sbDotSize, lp)

            val updateBtn = blueButton("Update check karo (v${BuildConfig.VERSION_NAME})")
            updateBtn.setOnClickListener { manualCheckUpdate(updateBtn) }
            col.addView(updateBtn, lp)

            val closeBtn = blueButton("Settings band karo")
            closeBtn.setOnClickListener { layoutSettings.visibility = View.GONE }
            col.addView(closeBtn, lp)

            layoutSettings.addView(col)
        }

        private fun manualCheckUpdate(btn: Button) {
            val oldText = btn.text
            btn.isEnabled = false
            btn.text = "Check ho raha hai…"
            UpdateChecker.check(ctx) { info ->
                btn.isEnabled = true
                btn.text = oldText
                if (info == null) {
                    Toast.makeText(ctx, "Lion up to date", Toast.LENGTH_SHORT).show()
                } else {
                    UpdateChecker.pending = info
                    refreshNotification()
                    try {
                        val themed = ContextThemeWrapper(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        val dialog = AlertDialog.Builder(themed)
                            .setTitle("Update available")
                            .setMessage("Lion ka naya version mila. Abhi update karein?")
                            .setPositiveButton("Update karo") { _, _ -> startUpdate(info) }
                            .setNegativeButton("Baad me", null)
                            .create()
                        dialog.window?.setType(overlayType())
                        dialog.show()
                    } catch (e: Exception) {
                        startUpdate(info)
                    }
                }
            }
        }

        // ── window params ─────────────────────────────────────────────────
        private fun setupWindowParams() {
            val m = ctx.resources.displayMetrics
            normalW = minOf(dp(360), m.widthPixels - dp(16))
            normalH = minOf(dp(500), m.heightPixels - dp(80))

            // Window B (browser): shuru me hidden
            params = WindowManager.LayoutParams(
                1, 1, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            params.gravity = Gravity.TOP or Gravity.START
            params.x = 0
            params.y = 0

            // Window A (dot + pill): kabhi focus nahi leta
            dotParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                dotParams.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            dotParams.gravity = Gravity.TOP or Gravity.START
            dotParams.x = dotCX - dp(20)
            dotParams.y = dotCY - dp(20)
        }

        private fun updateBrowserLayout() {
            try { wm.updateViewLayout(root, params) } catch (e: Exception) { }
        }

        private fun updateDotLayout() {
            try { wm.updateViewLayout(dotRoot, dotParams) } catch (e: Exception) { }
        }

        // browser window ka size/flags: hidden ya visible, normal ya maximized
        private fun applyBrowserParams() {
            if (!isBrowserShown) {
                params.x = 0
                params.y = 0
                params.width = 1
                params.height = 1
                params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            } else {
                if (isMaximized) {
                    params.x = 0
                    params.y = 0
                    params.width = WindowManager.LayoutParams.MATCH_PARENT
                    params.height = WindowManager.LayoutParams.MATCH_PARENT
                } else {
                    params.x = lastWindowX
                    params.y = lastWindowY
                    params.width = normalW
                    params.height = normalH
                }
                // focusable (no NOT_FOCUSABLE): keyboard / text input ke liye
                var f = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                // maximize: status bar + navigation bar ke peeche tak poori screen
                if (isMaximized) f = f or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                params.flags = f
            }
            updateBrowserLayout()
        }

        private fun applyTextSize(size: Float) {
            for (b in menuButtons) b.textSize = size
        }

        private fun applyOpacity(progress: Int) {
            dotView.alpha = maxOf(progress, 25) / 100f
        }

        private fun applyDotSize(sizeDp: Int) {
            val s = dp(sizeDp.coerceIn(10, 28))
            val lp = dotView.layoutParams as FrameLayout.LayoutParams
            lp.width = s
            lp.height = s
            dotView.layoutParams = lp
        }

        private fun loadSavedSettings() {
            val size = prefs.getInt("theme_size", 2)
            applyTextSize(12f + size)
            sbSize.progress = size

            val opacity = prefs.getInt("theme_opacity", 75)
            applyOpacity(opacity)
            sbOpacity.progress = opacity

            val ds = prefs.getInt("dot_size", 16).coerceIn(10, 28)
            applyDotSize(ds)
            sbDotSize.progress = ds - 10

            inputUrl.setText(prefs.getString("custom_url", AppConfig.DEFAULT_URL))
        }

        // ── dot + pill ────────────────────────────────────────────────────
        private fun pillW(): Int = dp(32) * menuButtons.size + dp(8)

        // dot ke center ke hisaab se Window A ki jagah set karo
        private fun placeDotWindow() {
            var x = dotCX - dp(20)
            if (isPillOpen) {
                if (pillOnLeft) x -= pillW()
                val sw = ctx.resources.displayMetrics.widthPixels
                val totalW = dp(40) + pillW()
                x = x.coerceIn(0, maxOf(0, sw - totalW)) // screen se bahar na jaye
            }
            dotParams.x = x
            dotParams.y = dotCY - dp(20)
            updateDotLayout()
        }

        private fun scheduleAutoCollapse() {
            handler.removeCallbacks(collapseRunnable)
            handler.postDelayed(collapseRunnable, 4000L)
        }

        private fun openPill() {
            if (isPillOpen) return
            val sw = ctx.resources.displayMetrics.widthPixels
            val pw = pillW()
            val fitsLeft = dotCX - dp(20) - pw >= 0
            val fitsRight = dotCX + dp(20) + pw <= sw
            val preferLeft = dotCX > sw / 2 // right half me ho to pill left me
            pillOnLeft = when {
                preferLeft && fitsLeft -> true
                !preferLeft && fitsRight -> false
                fitsLeft -> true
                fitsRight -> false
                else -> preferLeft
            }
            val plp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            if (pillOnLeft) dotRoot.addView(pill, 0, plp) else dotRoot.addView(pill, plp)
            isPillOpen = true
            placeDotWindow()
            scheduleAutoCollapse()
        }

        private fun closePill() {
            handler.removeCallbacks(collapseRunnable)
            if (!isPillOpen) return
            dotRoot.removeView(pill)
            isPillOpen = false
            placeDotWindow()
        }

        private fun togglePill() {
            if (isPillOpen) closePill() else openPill()
        }

        // ── browser show / hide ───────────────────────────────────────────
        private fun showBrowser() {
            if (isBrowserShown) return
            isBrowserShown = true
            root.visibility = View.VISIBLE
            btnWindow.text = "—"
            applyBrowserParams()
        }

        private fun hideBrowser() {
            if (!isBrowserShown) return
            layoutSettings.visibility = View.GONE
            isBrowserShown = false
            root.visibility = View.GONE
            btnWindow.text = "🪟"
            applyBrowserParams()
        }

        private fun toggleBrowser() {
            if (isBrowserShown) hideBrowser() else showBrowser()
        }

        // ── controls ──────────────────────────────────────────────────────
        private fun setupControls() {
            btnRefresh.setOnClickListener {
                scheduleAutoCollapse()
                showBrowser()
                webView.reload()
            }
            btnBack.setOnClickListener {
                scheduleAutoCollapse()
                showBrowser()
                if (webView.canGoBack()) webView.goBack()
            }
            btnMaximize.setOnClickListener {
                scheduleAutoCollapse()
                showBrowser()
                toggleMaximize()
            }
            btnWindow.setOnClickListener {
                scheduleAutoCollapse()
                toggleBrowser()
            }
            btnSettings.setOnClickListener {
                scheduleAutoCollapse()
                showBrowser()
                layoutSettings.visibility = View.VISIBLE
            }
            btnClose.setOnClickListener { this@FloatingService.stopSelf() }

            // dot: tap = browser show/hide, long-press = pill menu, drag = move, ❌ zone me chhodo = band
            var sX = 0; var sY = 0; var sTX = 0f; var sTY = 0f; var dragging = false
            dotWrapper.setOnTouchListener { _, e ->
                val m = ctx.resources.displayMetrics
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sX = dotCX; sY = dotCY; sTX = e.rawX; sTY = e.rawY
                        dragging = false
                        longPressed = false
                        handler.removeCallbacks(longPressRunnable)
                        handler.postDelayed(
                            longPressRunnable,
                            ViewConfiguration.getLongPressTimeout().toLong()
                        )
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val slop = if (longPressed) 30 else 10
                        if (dragging || abs(e.rawX - sTX) > slop || abs(e.rawY - sTY) > slop) {
                            if (!dragging) {
                                dragging = true
                                handler.removeCallbacks(longPressRunnable)
                                if (isPillOpen) closePill()
                                showCloseZone()
                            }
                            dotCX = (sX + (e.rawX - sTX).toInt()).coerceIn(0, m.widthPixels)
                            dotCY = (sY + (e.rawY - sTY).toInt()).coerceIn(0, m.heightPixels)
                            placeDotWindow()
                            val over = isOverCloseZone(e.rawX, e.rawY, m.widthPixels, m.heightPixels)
                            closeZone.scaleX = if (over) 1.3f else 1.0f
                            closeZone.scaleY = if (over) 1.3f else 1.0f
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        handler.removeCallbacks(longPressRunnable)
                        if (dragging) {
                            hideCloseZone()
                            if (isOverCloseZone(e.rawX, e.rawY, m.widthPixels, m.heightPixels)) {
                                this@FloatingService.stopSelf()
                            } else {
                                prefs.edit().putInt("dot_x", dotCX).putInt("dot_y", dotCY).apply()
                            }
                        } else if (longPressed) {
                            // menu khul chuka hai, ungli uthane par kuch nahi
                        } else {
                            // simple tap
                            if (isPillOpen) closePill() else toggleBrowser()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(longPressRunnable)
                        if (dragging) hideCloseZone()
                        true
                    }
                    else -> false
                }
            }

            // browser window drag (upar ka patla handle)
            var dX = 0; var dY = 0; var dTX = 0f; var dTY = 0f
            dragHandle.setOnTouchListener { _, e ->
                if (isMaximized) {
                    false
                } else when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        dX = params.x; dY = params.y; dTX = e.rawX; dTY = e.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = dX + (e.rawX - dTX).toInt()
                        params.y = dY + (e.rawY - dTY).toInt()
                        lastWindowX = params.x
                        lastWindowY = params.y
                        updateBrowserLayout()
                        true
                    }
                    else -> false
                }
            }

            // resize (◢)
            var rW = 0; var rH = 0; var rTX = 0f; var rTY = 0f
            resizeCorner.setOnTouchListener { _, e ->
                if (isMaximized) {
                    false
                } else when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        rW = params.width; rH = params.height; rTX = e.rawX; rTY = e.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.width = maxOf(dp(200), rW + (e.rawX - rTX).toInt())
                        params.height = maxOf(dp(260), rH + (e.rawY - rTY).toInt())
                        normalW = params.width
                        normalH = params.height
                        updateBrowserLayout()
                        true
                    }
                    else -> false
                }
            }

            // settings seekbars
            sbSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt("theme_size", progress).apply()
                    applyTextSize(12f + progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            sbOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt("theme_opacity", progress).apply()
                    applyOpacity(progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            sbDotSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val s = progress + 10
                    if (fromUser) prefs.edit().putInt("dot_size", s).apply()
                    applyDotSize(s)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        private fun showCloseZone() {
            if (isCloseZoneVisible) return
            try {
                wm.addView(closeZone, closeParams)
                isCloseZoneVisible = true
            } catch (e: Exception) { }
        }

        private fun hideCloseZone() {
            if (!isCloseZoneVisible) return
            try { wm.removeView(closeZone) } catch (e: Exception) { }
            isCloseZoneVisible = false
        }

        private fun isOverCloseZone(x: Float, y: Float, screenW: Int, screenH: Int): Boolean =
            y > screenH - dp(140) && x > screenW / 3 && x < (screenW * 2) / 3

        // ── maximize ──────────────────────────────────────────────────────
        private fun toggleMaximize() {
            isMaximized = !isMaximized
            dragHandle.visibility = if (isMaximized) View.GONE else View.VISIBLE
            applyBrowserParams()
        }

        // ── WebView ───────────────────────────────────────────────────────
        @Suppress("SetJavaScriptEnabled")
        private fun setupWebView() {
            val s = webView.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.allowContentAccess = true
            s.allowFileAccess = false
            s.setSupportMultipleWindows(true)
            s.javaScriptCanOpenWindowsAutomatically = true
            s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

            // Streamlit image/canvas OOM fix: hardware layer nahi
            webView.setLayerType(View.LAYER_TYPE_NONE, null)

            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            cm.setAcceptThirdPartyCookies(webView, true)

            webView.isFocusable = true
            webView.isFocusableInTouchMode = true

            // system long-press selection chalne do + apna Copy bar
            webView.isLongClickable = true
            webView.setOnLongClickListener { false }
            webView.addJavascriptInterface(Bridge(), "LionBridge")

            webView.webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, pageUrl: String?, favicon: Bitmap?) {
                    lastSelection = ""
                    editFocused = false
                    updateCopyBar()
                }

                override fun onPageFinished(view: WebView?, pageUrl: String?) {
                    CookieManager.getInstance().flush()
                    view?.evaluateJavascript(selectionJs, null)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val target = request?.url ?: return false
                    val scheme = (target.scheme ?: return false).lowercase()
                    // http/https (google search, login, kuch bhi) hamesha isi window me khule
                    if (scheme == "http" || scheme == "https") return false
                    // page ke apne internal schemes bhi yahin
                    if (scheme == "about" || scheme == "data" || scheme == "blob" ||
                        scheme == "javascript" || scheme == "file"
                    ) return false
                    // tel:, mailto:, intent:, upi: jaise links ko hi dusri app me kholo
                    val intent = Intent(Intent.ACTION_VIEW, target)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { ctx.startActivity(intent) } catch (e: Exception) { }
                    return true
                }

                // offline / site na mile: sirf main page par chhota error page (loop na bane)
                override fun onReceivedError(
                    view: WebView?, request: WebResourceRequest?, error: WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                    val req = request ?: return
                    if (!req.isForMainFrame) return
                    val failed = req.url.toString()
                    val jsUrl = failed
                        .replace("\\", "\\\\")
                        .replace("'", "\\'")
                        .replace("\n", "")
                        .replace("\r", "")
                        .replace("<", "%3C")
                    val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
                        "<body style='background:#1e222d;color:#d1d4dc;font-family:sans-serif;text-align:center;padding:40px 16px'>" +
                        "<h3>Internet / site nahi mil rahi</h3>" +
                        "<p>Connection check karke dobara try karo.</p>" +
                        "<button style='background:#2962ff;color:#fff;border:0;padding:12px 22px;font-size:16px;border-radius:6px' " +
                        "onclick=\"location.replace('" + jsUrl + "')\">Dobara try karo</button>" +
                        "</body></html>"
                    view?.loadDataWithBaseURL(failed, html, "text/html", "UTF-8", null)
                }

                // Streamlit/chart OOM me renderer mare to window dobara banao
                @android.annotation.TargetApi(26)
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    handler.post { this@FloatingService.restartWindow() }
                    return true
                }
            }

            webView.webChromeClient = object : WebChromeClient() {

                override fun onCreateWindow(
                    view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
                ): Boolean {
                    // target=_blank / window.open: naya window nahi, isi window me load karo
                    val msg = resultMsg ?: return false
                    val transport = msg.obj as? WebView.WebViewTransport ?: return false
                    val temp = WebView(ctx)
                    temp.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                            val u = r?.url?.toString()
                            if (u != null) handler.post { webView.loadUrl(u) }
                            handler.post { try { temp.destroy() } catch (e: Exception) { } }
                            return true
                        }
                    }
                    transport.webView = temp
                    msg.sendToTarget()
                    return true
                }

                override fun onJsPrompt(
                    view: WebView?, pageUrl: String?, message: String?,
                    defaultValue: String?, result: JsPromptResult?
                ): Boolean {
                    if (result == null) return false
                    return try {
                        val themed = ContextThemeWrapper(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        val input = EditText(themed)
                        input.setText(defaultValue ?: "")
                        val dialog = AlertDialog.Builder(themed)
                            .setTitle("Input chahiye")
                            .setMessage(message)
                            .setView(input)
                            .setPositiveButton("OK") { _, _ -> result.confirm(input.text.toString()) }
                            .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                            .setOnCancelListener { result.cancel() }
                            .create()
                        dialog.window?.setType(overlayType())
                        dialog.show()
                        true
                    } catch (e: Exception) {
                        result.cancel()
                        false
                    }
                }

                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (customView != null || view == null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = view
                    customViewCallback = callback
                    val parent = webView.parent as ViewGroup
                    val index = parent.indexOfChild(webView)
                    view.setBackgroundColor(Color.BLACK)
                    parent.addView(view, index, webView.layoutParams)
                    webView.visibility = View.GONE
                    if (!isMaximized) {
                        wasMaximizedByJS = true
                        toggleMaximize()
                    }
                }

                override fun onHideCustomView() {
                    val v = customView ?: return
                    (v.parent as? ViewGroup)?.removeView(v)
                    webView.visibility = View.VISIBLE
                    if (wasMaximizedByJS) {
                        if (isMaximized) toggleMaximize()
                        wasMaximizedByJS = false
                    }
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                }

                override fun onShowFileChooser(
                    webViewParam: WebView?,
                    callback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: WebChromeClient.FileChooserParams?
                ): Boolean {
                    if (callback == null || fileChooserParams == null) return false
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = callback
                    return try {
                        val picker = fileChooserParams.createIntent()
                        val host = Intent(ctx, FileChooserActivity::class.java)
                        host.putExtra(Intent.EXTRA_INTENT, picker)
                        host.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(host)
                        true
                    } catch (e: Exception) {
                        filePathCallback = null
                        Toast.makeText(ctx, "File picker open nahi ho paya: " + e.message, Toast.LENGTH_LONG).show()
                        false
                    }
                }
            }
        }
    }
}
