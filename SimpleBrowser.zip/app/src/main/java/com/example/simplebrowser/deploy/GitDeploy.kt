package com.example.simplebrowser.deploy

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.text.InputType
import android.util.Base64
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import com.example.simplebrowser.DlSettings
import com.example.simplebrowser.R
import com.example.simplebrowser.UpdateChecker
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Auto Deploy (GitHub): phone ke Download folder me `SimpleBrowser*.zip` (ya `Simple Browser(1).zip` jaisa naam) aate hi use GitHub repo me daal do.
 *
 * - Zip jaisi hai waisi hi repo me ek file ban kar jati hai (khol kar commit nahi hoti).
 * - Chrome se `SimpleBrowser(1).zip` jaise naam se aaye to bhi chalega.
 * - File poori download hone ke baad hi uthti hai (size 2 baar same + zip khulti ho).
 * - VERSION NAAM: zip ke andar kuch nahi badalta. App khud naam deta hai: SimpleBrowser1.zip, SimpleBrowser2.zip...
 *   (AI ne zip ka naam kuch bhi diya ho, farak nahi). Same content dobara aaye to wahi purana number milta hai.
 * - Download me sabse nayi `SimpleBrowser<N>.zip` rehti hai; purani saari versions `Download/SimpleBrowserVersions/`
 *   me bachi rehti hain (kuch delete nahi hota, sirf bilkul same content ki duplicate hatti hai).
 * - GitHub par file ka naam wahi rehta hai (default `SimpleBrowser.zip`); commit message me version likha hota hai.
 *   Fail ho to kuch delete / rename nahi hota.
 * - Login GitHub token se (fine-grained token, sirf usi repo par "Contents: Read and write").
 */
object GitDeploy {
    const val K_ON = "gh_on"
    const val K_SRC = "gh_src"            // phone ka folder (default Download)
    const val K_PAT = "gh_pat"            // phone me file naam pattern
    const val K_LAST = "gh_last"          // last status text
    const val K_REPO = "gh_repo"          // owner/repo
    const val K_BRANCH = "gh_branch"
    const val K_PATH = "gh_path"          // repo ke andar file ka path
    const val K_TOKEN = "gh_token"
    private const val K_DONE = "gh_done"
    private const val K_VER = "gh_ver"              // version list: "N|sha256" har line
    const val VER_DIR = "SimpleBrowserVersions"
    private const val K_WSINCE = "gh_w_since"   // build-watch kab shuru hua (ms); khali = watch band
    private const val K_WBASE = "gh_w_base"     // upload ke waqt latest release ka id (naya wahi jo isse bada ho)
    private const val WATCH_MAX_MS = 20L * 60 * 1000   // itna intezaar, phir "release nahi mila"
    private const val POLL_MS = 45_000L

    const val DEF_PAT = "Simple*Browser*.zip"      // SimpleBrowser.zip, SimpleBrowser(1).zip, Simple Browser(1).zip sab
    const val DEF_REPO = "krishna123814/Replay"
    const val DEF_BRANCH = "main"
    const val DEF_PATH = "SimpleBrowser.zip"
    private const val MAX_BYTES = 25L * 1024 * 1024     // API se bhejne ki hamari seema (memory me base64 banta hai)

    fun on(ctx: Context): Boolean = DlSettings.getBool(ctx, K_ON, false)
    fun setOn(ctx: Context, v: Boolean) = DlSettings.setBool(ctx, K_ON, v)

    fun srcDir(ctx: Context): String =
        DlSettings.getStr(ctx, K_SRC, "").ifBlank {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
        }

    fun pattern(ctx: Context): String = DlSettings.getStr(ctx, K_PAT, DEF_PAT).ifBlank { DEF_PAT }
    private fun repo(ctx: Context) = DlSettings.getStr(ctx, K_REPO, DEF_REPO).trim().ifBlank { DEF_REPO }
    private fun branch(ctx: Context) = DlSettings.getStr(ctx, K_BRANCH, DEF_BRANCH).trim()
    private fun path(ctx: Context) = DlSettings.getStr(ctx, K_PATH, DEF_PATH).trim().trim('/').ifBlank { DEF_PATH }
    private fun token(ctx: Context) = DlSettings.getStr(ctx, K_TOKEN, "").trim()
    private fun finalName(ctx: Context) = path(ctx).substringAfterLast('/')

    fun last(ctx: Context): String = DlSettings.getStr(ctx, K_LAST, "")
    fun setLast(ctx: Context, msg: String) {
        val t = SimpleDateFormat("dd MMM HH:mm:ss", Locale.US).format(Date())
        DlSettings.setStr(ctx, K_LAST, "$t  $msg")
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun globRegex(p: String): Regex {
        val sb = StringBuilder()
        for (ch in p.trim()) {
            when (ch) {
                '*' -> sb.append(".*")
                '?' -> sb.append('.')
                else -> sb.append(Regex.escape(ch.toString()))
            }
        }
        return Regex(sb.toString(), RegexOption.IGNORE_CASE)
    }

    private fun doneSet(ctx: Context): MutableList<String> =
        DlSettings.getStr(ctx, K_DONE, "").split('\n').filter { it.isNotEmpty() }.toMutableList()

    private fun markDone(ctx: Context, sig: String) {
        val l = doneSet(ctx)
        l.add(sig)
        while (l.size > 50) l.removeAt(0)
        DlSettings.setStr(ctx, K_DONE, l.joinToString("\n"))
    }

    private fun zipProblem(f: File): String? = try {
        java.util.zip.ZipFile(f).use { if (it.size() == 0) "zip khaali hai" else null }
    } catch (e: Exception) {
        "zip poori nahi / kharab hai"
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun encPath(p: String): String = p.split('/').joinToString("/") { enc(it) }

    // ───────────────────────── GitHub API ─────────────────────────

    private class Resp(val code: Int, val body: String)

    private fun call(method: String, url: String, token: String, body: ByteArray?): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20000
            c.readTimeout = 120000
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            c.setRequestProperty("User-Agent", "SimpleBrowser-AutoDeploy")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setFixedLengthStreamingMode(body.size)
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            val st = if (code >= 400) c.errorStream else c.inputStream
            val txt = st?.bufferedReader()?.use { it.readText() } ?: ""
            return Resp(code, txt)
        } finally {
            try { c.disconnect() } catch (_: Throwable) { }
        }
    }

    private fun why(r: Resp): String {
        val m = try { JSONObject(r.body).optString("message", "") } catch (_: Exception) { "" }
        val hint = when (r.code) {
            401 -> "token galat ya expire"
            403 -> "token ko permission nahi ya limit"
            404 -> "repo / branch / path nahi mila (ya token ko is repo ka access nahi)"
            409, 422 -> "file badal gayi, dobara koshish hogi"
            else -> ""
        }
        return "HTTP ${r.code}" + (if (hint.isNotEmpty()) " — $hint" else "") + (if (m.isNotEmpty()) " ($m)" else "")
    }

    private fun contentsUrl(repo: String, path: String) =
        "https://api.github.com/repos/$repo/contents/" + encPath(path)

    // ───────────────────────── scan + upload ─────────────────────────

    /**
     * Ek round: Download folder me jitni `SimpleBrowser*.zip` hain unme se sirf SABSE NAYI dekhi jati hai.
     * Stable + sahi zip ho to GitHub par jati hai; safal hone ke baad baaki purani delete aur ye `SimpleBrowser.zip` ban jati hai.
     * true = sab theek, false = upload fail (service 30s ruk kar dobara koshish karegi).
     */
    fun tick(ctx: Context, seen: HashMap<String, LongArray>): Boolean {
        if (!AutoDeploy.hasAllFiles()) {
            setLast(ctx, "❌ \"All files access\" permission do (Settings se)")
            return true
        }
        val dir = File(srcDir(ctx))
        val rx = globRegex(pattern(ctx))
        val list = dir.listFiles { f -> f.isFile && rx.matches(f.name) } ?: return true
        val f = list.maxByOrNull { it.lastModified() } ?: return true   // sabse nayi
        val fin = finalName(ctx)
        val sig = f.name + "|" + f.length() + "|" + f.lastModified()
        val done = doneSet(ctx)

        // Ye file pehle hi upload ho chuki hai: bas safai (purani hatao, naam theek karo) agar baaki ho.
        if (done.contains(sig)) {
            val verRx = Regex("^" + Regex.escape(stem(fin)) + "\\d+\\." + Regex.escape(ext(fin)) + "$", RegexOption.IGNORE_CASE)
            if (list.size > 1 || !verRx.matches(f.name)) tidy(ctx, f, list, fin)
            return true
        }

        val s = seen[f.name]
        if (s == null || s[0] != f.length() || s[1] != f.lastModified()) {
            seen[f.name] = longArrayOf(f.length(), f.lastModified(), 1L)
            return true
        }
        s[2] = s[2] + 1
        if (s[2] < 2L) return true                    // size 2 round (~3 sec) same ho tab hi
        val bad = zipProblem(f) ?: if (f.length() > MAX_BYTES) "file 25 MB se badi hai" else null
        if (bad != null) {
            if (s[2] == 8L) {                         // ~20 sec baad bhi kharab to bata do
                setLast(ctx, "⚠️ ${f.name}: $bad")
                result(ctx, "⚠️ ${f.name} GitHub par nahi gayi", bad)
            }
            return true
        }
        val ok = upload(ctx, f, sig, list, fin)
        if (ok) seen.clear()
        return ok
    }

    // ───────────────────────── version naam ─────────────────────────

    private fun stem(fin: String): String = fin.substringBeforeLast('.', fin)
    private fun ext(fin: String): String = fin.substringAfterLast('.', "zip")

    private fun sha256(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun verList(ctx: Context): MutableList<Pair<Int, String>> =
        DlSettings.getStr(ctx, K_VER, "").split('\n').mapNotNull {
            val p = it.split('|')
            val n = p.getOrNull(0)?.toIntOrNull()
            val h = p.getOrNull(1)
            if (n != null && !h.isNullOrEmpty()) Pair(n, h) else null
        }.toMutableList()

    /**
     * SimpleBrowserVersions me pehle se bani sabse badi version number (settings reset ho gayi ho tab bhi).
     * Download folder nahi dekhte: wahan AI ka diya naam number ko galat ghuma deta.
     */
    private fun maxVersionOnDisk(ctx: Context, fin: String): Int {
        val rx = Regex("^" + Regex.escape(stem(fin)) + "(\\d+)\\." + Regex.escape(ext(fin)) + "$", RegexOption.IGNORE_CASE)
        var m = 0
        File(File(srcDir(ctx)), VER_DIR).listFiles()?.forEach { f ->
            rx.find(f.name)?.groupValues?.get(1)?.toIntOrNull()?.let { if (it > m) m = it }
        }
        return m
    }

    /** Is file ka version number: same content pehle aaya ho to wahi number, nahi to agla naya number. */
    @Synchronized
    private fun versionOf(ctx: Context, f: File, fin: String): Int {
        val h = sha256(f)
        val l = verList(ctx)
        l.firstOrNull { it.second == h }?.let { return it.first }
        val n = maxOf(l.maxOfOrNull { it.first } ?: 0, maxVersionOnDisk(ctx, fin)) + 1
        l.add(Pair(n, h))
        DlSettings.setStr(ctx, K_VER, l.joinToString("\n") { it.first.toString() + "|" + it.second })
        return n
    }

    private fun versionName(ctx: Context, f: File, fin: String): String =
        stem(fin) + versionOf(ctx, f, fin) + "." + ext(fin)

    /**
     * Upload ke baad: nayi `keep` ka naam `SimpleBrowser<N>.zip` kar do (Download me yahi latest rehti hai),
     * uski ek copy `SimpleBrowserVersions/` me rakho, aur baaki purani matching files wahin bhej do.
     * Kuch delete nahi hota — sirf wo file jiska bilkul same content pehle se SimpleBrowserVersions me ho.
     */
    private fun tidy(ctx: Context, keep: File, all: Array<File>, fin: String): String {
        val vdir = File(keep.parentFile, VER_DIR)
        vdir.mkdirs()
        val parts = ArrayList<String>()
        var moved = 0
        for (o in all) {
            if (o.absolutePath == keep.absolutePath) continue
            try {
                val dest = File(vdir, versionName(ctx, o, fin))
                if (dest.exists()) {
                    o.delete()                       // same content pehle se bachi hai
                } else if (o.renameTo(dest) || (runCatching { o.copyTo(dest, false); o.delete() }.isSuccess)) {
                    moved++
                }
            } catch (_: Throwable) {
            }
        }
        if (moved > 0) parts.add("$moved purani SimpleBrowserVersions me")
        val vname = versionName(ctx, keep, fin)
        try {
            val cp = File(vdir, vname)
            if (!cp.exists()) keep.copyTo(cp, false)
        } catch (_: Throwable) {
        }
        if (keep.name != vname) {
            val target = File(keep.parentFile, vname)
            val len = keep.length()
            val mod = keep.lastModified()
            if (target.exists() && !target.delete()) {
                parts.add("naam badal nahi payi")
            } else if (keep.renameTo(target)) {
                markDone(ctx, vname + "|" + len + "|" + mod)
                parts.add("naam $vname kiya")
            } else {
                parts.add("naam badal nahi payi")
            }
        }
        return parts.joinToString(", ")
    }

    private fun upload(ctx: Context, f: File, sig: String, all: Array<File>, fin: String): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lion:gitdeploy")
        wl.acquire(10L * 60 * 1000)
        try {
            val tok = token(ctx)
            if (tok.isEmpty()) {
                setLast(ctx, "❌ GitHub token daalo (⚙ settings me)")
                return false
            }
            val repo = repo(ctx)
            if (!repo.contains('/')) {
                setLast(ctx, "❌ Repo daalo, jaise owner/repo (⚙ settings me)")
                return false
            }
            val path = path(ctx)
            val br = branch(ctx)
            setLast(ctx, "⬆ ${f.name} → ${versionName(ctx, f, fin)} GitHub par ja rahi hai…")

            val base = contentsUrl(repo, path)
            val getUrl = if (br.isEmpty()) base else base + "?ref=" + enc(br)
            val g = call("GET", getUrl, tok, null)
            var sha: String? = null
            if (g.code == 200) {
                val t = g.body.trim()
                if (t.startsWith("[")) {
                    setLast(ctx, "❌ $path GitHub par folder hai, file nahi")
                    return false
                }
                val sh = JSONObject(t).optString("sha", "")
                if (sh.isNotEmpty()) sha = sh
            } else if (g.code != 404) {
                setLast(ctx, "❌ GitHub fail: " + why(g) + " (30 sec baad dobara)")
                return false
            }

            val stamp = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.US).format(Date())
            val vname = versionName(ctx, f, fin)
            val vnum = vname.removePrefix(stem(fin)).removeSuffix("." + ext(fin))
            val j = JSONObject()
            j.put("message", "Update $fin (v$vnum, $stamp)")
            j.put("content", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
            if (br.isNotEmpty()) j.put("branch", br)
            if (sha != null) j.put("sha", sha)
            val p = call("PUT", base, tok, j.toString().toByteArray(Charsets.UTF_8))
            if (p.code != 200 && p.code != 201) {
                setLast(ctx, "❌ Upload fail: " + why(p) + " (30 sec baad dobara)")
                return false
            }

            markDone(ctx, sig)
            startWatch(ctx, repo, tok)
            val note = tidy(ctx, f, all, fin)
            val extra = if (note.isEmpty()) "" else " ($note)"
            val where = "$repo/$path" + (if (br.isEmpty()) "" else " [$br]")
            setLast(ctx, "✅ $vname (${f.name}) → $where$extra — ⏳ build ka intezaar")
            result(ctx, "✅ $vname GitHub par pahunch gayi", "${f.name} → $where  (version: $vname)")
            return true
        } catch (e: Exception) {
            val m = (e.message ?: e.javaClass.simpleName)
            setLast(ctx, "❌ Upload fail: $m (30 sec baad dobara)")
            return false
        } catch (e: OutOfMemoryError) {
            setLast(ctx, "❌ Memory kam padi, file badi hai (30 sec baad dobara)")
            return false
        } finally {
            try {
                if (wl.isHeld) wl.release()
            } catch (_: Throwable) {
            }
        }
    }

    // ───────────────────────── build watch: upload ke baad naya release aate hi APK download ─────────────────────────

    private class Rel(val id: Long, val vc: Long?, val url: String)

    @Volatile private var lastPoll = 0L
    @Volatile private var dlBusy = false

    private fun watchSince(ctx: Context): Long = DlSettings.getStr(ctx, K_WSINCE, "").toLongOrNull() ?: 0L
    private fun watchBase(ctx: Context): Long = DlSettings.getStr(ctx, K_WBASE, "").toLongOrNull() ?: -1L
    private fun stopWatch(ctx: Context) {
        DlSettings.setStr(ctx, K_WSINCE, "")
        DlSettings.setStr(ctx, K_WBASE, "")
    }

    /** Build ka intezaar chalu hai? (service ko zinda rakhne ke liye) */
    fun watching(ctx: Context): Boolean = watchSince(ctx) > 0L

    private fun latestRelease(repo: String, tok: String): Rel? {
        val r = call("GET", "https://api.github.com/repos/$repo/releases/latest", tok, null)
        if (r.code == 404) return null                 // abhi koi release nahi
        if (r.code != 200) throw Exception(why(r))
        val o = JSONObject(r.body)
        val vc = o.optString("tag_name", "").removePrefix("build-").toLongOrNull()
        var url = ""
        val assets = o.optJSONArray("assets")
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                    url = a.optString("browser_download_url")
                    break
                }
            }
        }
        return Rel(o.optLong("id", 0L), vc, url)
    }

    /** Upload safal hote hi: abhi ka latest release yaad rakho; ab jo isse naya aaye wahi hamara build hoga. */
    private fun startWatch(ctx: Context, repo: String, tok: String) {
        val base = try { latestRelease(repo, tok)?.id ?: 0L } catch (e: Exception) { -1L }   // -1 = baad me pehli poll se
        DlSettings.setStr(ctx, K_WBASE, base.toString())
        DlSettings.setStr(ctx, K_WSINCE, System.currentTimeMillis().toString())
        lastPoll = System.currentTimeMillis()
    }

    /** Service har ~3 sec bulati hai; asli check ~45 sec me ek baar. */
    fun watchTick(ctx: Context) {
        val since = watchSince(ctx)
        if (since <= 0L || dlBusy) return
        val now = System.currentTimeMillis()
        if (now - since > WATCH_MAX_MS) {
            stopWatch(ctx)
            setLast(ctx, "⚠️ 20 min me naya build release nahi mila (GitHub Actions dekho)")
            result(ctx, "⚠️ Build ka release nahi mila", "GitHub Actions me dekho: build fail ya der ho sakti hai")
            return
        }
        if (now - lastPoll < POLL_MS) return
        lastPoll = now
        val tok = token(ctx)
        val repo = repo(ctx)
        if (tok.isEmpty() || !repo.contains('/')) return
        val rel = try { latestRelease(repo, tok) } catch (e: Exception) { return }   // net dikkat: agli baar dobara
        if (rel == null) return
        val base = watchBase(ctx)
        if (base < 0L) {                                // upload ke waqt base nahi mila tha
            DlSettings.setStr(ctx, K_WBASE, rel.id.toString())
            return
        }
        if (rel.id <= base) return                      // naya release abhi nahi bana
        if (rel.url.isEmpty()) return                   // release bana par APK abhi lagi nahi
        val local = UpdateChecker.installedVersion(ctx)
        if (rel.vc != null && rel.vc <= local) {
            stopWatch(ctx)
            setLast(ctx, "ℹ️ Naya release bana par version wahi hai (${rel.vc}), install ki zaroorat nahi")
            return
        }
        dlBusy = true
        Thread {
            try {
                setLast(ctx, "⬇ Naya build download ho raha hai…")
                val apkIntent = UpdateChecker.downloadForInstall(ctx, rel.url)
                UpdateChecker.readyInstallIntent = apkIntent
                stopWatch(ctx)
                setLast(ctx, "✅ Naya build ready — notification me \"Install karo\" dabao")
                installNotify(ctx, apkIntent)
            } catch (e: Exception) {
                setLast(ctx, "❌ Build download fail: " + (e.message ?: e.javaClass.simpleName) + " (dobara koshish hogi)")
            } finally {
                dlBusy = false
            }
        }.start()
    }

    private fun installNotify(ctx: Context, install: Intent) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("deploy_install", "Naya build ready", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val pi = PendingIntent.getActivity(ctx, 81, install, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(ctx, "deploy_install")
                .setSmallIcon(R.drawable.ic_notif_lion)
                .setContentTitle("✅ Naya Lion build ready")
                .setContentText("Install karne ke liye tap karo")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(81, n)
        } catch (_: Throwable) {
        }
    }

    private fun result(ctx: Context, title: String, text: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("deploy_res", "Auto Deploy result", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val n = NotificationCompat.Builder(ctx, "deploy_res")
                .setSmallIcon(R.drawable.ic_notif_lion)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .build()
            nm.notify(80, n)
        } catch (_: Throwable) {
        }
    }

    // ───────────────────────── settings dialog ─────────────────────────

    fun showSettings(act: Activity, onClose: () -> Unit) {
        val pad = (16 * act.resources.displayMetrics.density).toInt()
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)

        fun label(t: String) {
            val tv = TextView(act)
            tv.text = t
            tv.textSize = 12f
            tv.setPadding(0, pad / 2, 0, 0)
            box.addView(tv)
        }

        fun field(v: String, pw: Boolean = false): EditText {
            val e = EditText(act)
            e.setSingleLine(true)
            e.textSize = 14f
            if (pw) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            e.setText(v)
            box.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return e
        }

        fun cleanRepo(s: String): String {
            var r = s.trim()
            r = r.removePrefix("https://github.com/").removePrefix("http://github.com/").removePrefix("github.com/")
            r = r.removeSuffix("/").removeSuffix(".git")
            return r
        }

        label("Phone ka folder (yahan se file uthegi)")
        val eSrc = field(srcDir(act))
        label("Phone me file ka naam (* = kuch bhi)")
        val ePat = field(pattern(act))
        label("GitHub repo (owner/repo)")
        val eRepo = field(repo(act))
        label("Branch (khali = repo ka default)")
        val eBr = field(branch(act))
        label("Repo me file ka path (jaise SimpleBrowser.zip ya backup/SimpleBrowser.zip)")
        val ePath = field(path(act))
        label("GitHub token (fine-grained, Contents: Read and write)")
        val eTok = field(token(act), pw = true)

        if (!AutoDeploy.hasAllFiles()) {
            val b = Button(act)
            b.text = "📂 All files access do"
            b.setOnClickListener { AutoDeploy.askAllFiles(act) }
            box.addView(b)
        }

        val st = TextView(act)
        st.textSize = 11f
        st.setPadding(0, pad / 2, 0, 0)
        st.setTextIsSelectable(true)
        st.text = last(act).ifBlank { "Abhi koi file nahi uthi" }

        val test = Button(act)
        test.text = "🔌 Connection test"
        test.setOnClickListener {
            val r = cleanRepo(eRepo.text.toString())
            val b = eBr.text.toString().trim()
            val tk = eTok.text.toString().trim()
            st.text = "Test chal raha hai…"
            Thread {
                var msg = ""
                try {
                    if (tk.isEmpty()) {
                        msg = "❌ Token daalo"
                    } else if (!r.contains('/')) {
                        msg = "❌ Repo owner/repo format me daalo"
                    } else {
                        val rr = call("GET", "https://api.github.com/repos/$r", tk, null)
                        if (rr.code != 200) {
                            msg = "❌ " + why(rr)
                        } else {
                            val o = JSONObject(rr.body)
                            val perm = o.optJSONObject("permissions")
                            val push = if (perm == null) "write access upload par pata chalega" else if (perm.optBoolean("push", false)) "write access ✔" else "write access NAHI ✘"
                            msg = "✅ Repo mila: ${o.optString("full_name", r)} ($push)"
                            if (b.isNotEmpty()) {
                                val br = call("GET", "https://api.github.com/repos/$r/branches/" + enc(b), tk, null)
                                msg += if (br.code == 200) "\n✅ Branch $b mili" else "\n❌ Branch $b: " + why(br)
                            }
                        }
                    }
                } catch (e: Exception) {
                    msg = "❌ " + (e.message ?: e.javaClass.simpleName)
                }
                Handler(Looper.getMainLooper()).post { st.text = msg }
            }.start()
        }
        box.addView(test)
        box.addView(st)

        val sv = ScrollView(act)
        sv.addView(box)

        AlertDialog.Builder(act)
            .setTitle("🐙 Auto Deploy (GitHub)")
            .setView(sv)
            .setPositiveButton("Save") { _, _ ->
                DlSettings.setStr(act, K_SRC, eSrc.text.toString().trim())
                DlSettings.setStr(act, K_PAT, ePat.text.toString().trim().ifBlank { DEF_PAT })
                DlSettings.setStr(act, K_REPO, cleanRepo(eRepo.text.toString()).ifBlank { DEF_REPO })
                DlSettings.setStr(act, K_BRANCH, eBr.text.toString().trim())
                DlSettings.setStr(act, K_PATH, ePath.text.toString().trim().trim('/').ifBlank { DEF_PATH })
                DlSettings.setStr(act, K_TOKEN, eTok.text.toString().trim())
                Toast.makeText(act, "Save ho gaya", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Band", null)
            .setOnDismissListener { onClose() }
            .show()
    }
}
