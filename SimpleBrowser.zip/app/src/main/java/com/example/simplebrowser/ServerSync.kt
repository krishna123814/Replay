package com.example.simplebrowser

import android.content.Context
import android.net.Uri
import android.util.Xml
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Credentials
import okio.BufferedSink
import okio.source
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Download hote hi file ko server (AIC Disk /dav/ ya HF Bucket /hf/) ke chune hue folder me bhejna (WebDAV PUT).
 * MyFiles app jaisa hi login: URL + username + password.
 */
object ServerSync {

    const val K_STORE = "ss_store"      // off | aic | hf
    const val K_URL = "ss_url"
    const val K_USER = "ss_user"
    const val K_PASS = "ss_pass"
    const val K_PATH = "ss_path"        // jaise "/video/punjabi"
    const val K_DELETE = "ss_delete"
    const val K_DIRECT = "ss_direct"    // true = link server ko do, server khud download kare (phone me file nahi aati)
    const val DEFAULT_URL = "https://u8cyy.aiccloud.online/dav/"

    private val io = Executors.newFixedThreadPool(1)
    private val net = Executors.newCachedThreadPool()

    fun store(ctx: Context): String = DlSettings.getStr(ctx, K_STORE, "off")
    fun enabled(ctx: Context): Boolean = store(ctx) != "off" && DlSettings.getStr(ctx, K_USER, "").isNotEmpty()
    fun path(ctx: Context): String = DlSettings.getStr(ctx, K_PATH, "/")
    private fun baseUrl(ctx: Context): String = Dav.slash(DlSettings.getStr(ctx, K_URL, DEFAULT_URL).trim())

    private fun client(ctx: Context): OkHttpClient {
        val host = baseUrl(ctx).toHttpUrlOrNull()?.host
        val auth = Credentials.basic(DlSettings.getStr(ctx, K_USER, ""), DlSettings.getStr(ctx, K_PASS, ""))
        return OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(300, TimeUnit.SECONDS)
            .writeTimeout(300, TimeUnit.SECONDS)
            .addInterceptor(Interceptor { chain ->
                val r = chain.request()
                if (host != null && r.url.host == host) chain.proceed(r.newBuilder().header("Authorization", auth).build())
                else chain.proceed(r)
            })
            .build()
    }

    /** Storage ka root URL: AIC = .../dav/, HF = .../hf/ (login URL se). */
    fun root(ctx: Context, store: String): String {
        val b = baseUrl(ctx)
        val parent = when {
            b.endsWith("/dav/") -> b.dropLast(4)
            b.endsWith("/hf/") -> b.dropLast(3)
            else -> {
                val u = b.toHttpUrlOrNull()
                if (u == null) b else u.newBuilder().encodedPath("/").query(null).fragment(null).build().toString()
            }
        }
        return parent + if (store == "hf") "hf/" else "dav/"
    }

    private fun urlOf(ctx: Context, store: String, path: String): String {
        val sb = StringBuilder(root(ctx, store))
        for (seg in path.trim('/').split('/').filter { it.isNotEmpty() }) sb.append(Uri.encode(seg)).append('/')
        return sb.toString()
    }


    // ── DIRECT: server khud download kare (phone sirf link + cookie bhejta hai) ──
    fun direct(ctx: Context): Boolean = enabled(ctx) && DlSettings.getBool(ctx, K_DIRECT, true)

    private fun xferBase(ctx: Context, store: String): String {
        val r = root(ctx, store)
        return r.substring(0, r.length - (if (store == "hf") 3 else 4)) + "xfer/"
    }

    private fun jsonBody(o: JSONObject) = o.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

    /**
     * Link server ko bhejo (POST /xfer/dl). Server bhejne me ya download me fail ho to [onFail] chalta hai
     * (purana tareeka: phone par download, phir upload), taaki kuch kho na jaye.
     * kind: "auto" | "file" | "hls" | "ytdlp"
     */
    fun sendDirect(ctx: Context, spec: DlSpec, kind: String, onFail: () -> Unit) {
        val app = ctx.applicationContext
        val store = store(app)
        val path = path(app)
        net.execute {
            var id = ""
            try {
                val body = JSONObject()
                    .put("url", spec.url).put("name", spec.name).put("cookie", spec.cookie)
                    .put("ua", spec.ua).put("referer", spec.referer).put("kind", kind)
                    .put("on_conflict", "rename")
                    .put("dest", JSONObject().put("store", store).put("path", path))
                val req = Request.Builder().url(xferBase(app, store) + "dl").post(jsonBody(body)).build()
                client(app).newCall(req).execute().use { r ->
                    val txt = r.body?.string() ?: ""
                    if (r.code == 401) throw IOException("Username / password galat")
                    if (!r.isSuccessful) {
                        val m = try { JSONObject(txt).optString("error") } catch (e: Exception) { "" }
                        throw IOException(if (m.isNotEmpty()) m else "HTTP ${r.code}")
                    }
                    id = JSONObject(txt).optString("id")
                }
                if (id.isEmpty()) throw IOException("server ne id nahi di")
            } catch (e: Throwable) {
                DlEngine.toast("☁ Server ko link nahi bheja, phone par utar rahe hain: " + (e.message ?: e.javaClass.simpleName))
                onFail()
                return@execute
            }
            histAdd(app, id, spec.name, spec.url, store, path)
            DlEngine.toast("☁ Server par download shuru: " + spec.name)
            pollDirect(app, store, id, spec.name, onFail)
        }
    }



    fun qualityName(height: Int): String = when {
        height < 0 -> "sirf audio mp3"
        height == 0 -> "best quality"
        else -> height.toString() + "p tak"
    }

    /** Server se ek video ke quality options. */
    class FormatOpt(val h: Int, val ext: String, val fps: Int, val count: Int, val sampled: Int)

    /**
     * Chune hue videos me se pehle <=3 ke formats server (yt-dlp) se padho; heights ka union do.
     * [cb] background thread par chalta hai. Khaali list = padh nahi payi (caller standard ladder dikhaye).
     */
    fun fetchFormats(ctx: Context, specs: List<DlSpec>, cb: (List<FormatOpt>, Boolean) -> Unit) {
        val app = ctx.applicationContext
        val store = store(app)
        net.execute {
            val sample = specs.take(3)
            val futures = sample.map { spec ->
                net.submit(java.util.concurrent.Callable<JSONObject?> {
                    try {
                        val body = JSONObject().put("url", spec.url).put("cookie", spec.cookie)
                            .put("ua", spec.ua).put("referer", spec.referer)
                        val req = Request.Builder().url(xferBase(app, store) + "formats").post(jsonBody(body)).build()
                        client(app).newCall(req).execute().use { r ->
                            val txt = r.body?.string() ?: ""
                            if (r.isSuccessful) JSONObject(txt) else null
                        }
                    } catch (e: Throwable) { null }
                })
            }
            val got = futures.mapNotNull {
                try { it.get(60, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Throwable) { null }
            }
            val byH = java.util.TreeMap<Int, IntArray>()      // height -> [count, fps]
            val extOf = HashMap<Int, String>()
            var audio = false
            for (j in got) {
                if (j.optBoolean("audio")) audio = true
                val arr = j.optJSONArray("formats") ?: continue
                for (i in 0 until arr.length()) {
                    val f = arr.optJSONObject(i) ?: continue
                    val h = f.optInt("h")
                    if (h <= 0) continue
                    val cur = byH.getOrPut(h) { intArrayOf(0, 0) }
                    cur[0]++
                    cur[1] = maxOf(cur[1], f.optInt("fps"))
                    if (!extOf.containsKey(h)) extOf[h] = f.optString("ext")
                }
            }
            val list = byH.descendingMap().map { (h, v) -> FormatOpt(h, extOf[h] ?: "", v[1], v[0], got.size) }
            cb(list, audio || got.isEmpty())
        }
    }


    // ── Server downloads ka local record: jo link server ko bheje, unki state yaad rakhte hain ──
    // (server restart ho jaye ya purani job server se hat jaye tab bhi "ab tak ki downloads" me dikhti rehti hain)
    class SrvRow(
        val id: String, val name: String, val url: String, val store: String, val path: String,
        val t: Long, val state: String, val done: Long, val total: Long, val result: String, val error: String
    ) {
        val active: Boolean get() = state == "queued" || state == "running"
        val removed: Boolean get() = error.startsWith("[removed]")
    }

    private const val K_HIST = "srv_hist"
    private val histLock = Any()

    private fun histLoad(app: Context): JSONArray =
        try { JSONArray(DlSettings.getStr(app, K_HIST, "[]")) } catch (e: Exception) { JSONArray() }

    private fun histSave(app: Context, a: JSONArray) {
        var arr = a
        if (arr.length() > 500) {            // sabse purani khatam hui entries hatao
            val keep = JSONArray()
            var drop = arr.length() - 500
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val st = o.optString("state")
                if (drop > 0 && st != "queued" && st != "running") { drop--; continue }
                keep.put(o)
            }
            arr = keep
        }
        DlSettings.setStr(app, K_HIST, arr.toString())
    }

    fun histAdd(app: Context, id: String, name: String, url: String, store: String, path: String) {
        synchronized(histLock) {
            val a = histLoad(app)
            a.put(
                JSONObject().put("id", id).put("name", name.ifEmpty { url }).put("url", url)
                    .put("store", store).put("path", path).put("t", System.currentTimeMillis())
                    .put("state", "queued").put("done", 0).put("total", 0).put("result", "").put("err", "")
            )
            histSave(app, a)
        }
    }

    /** Server ki job-list (ya ek job) se record ki states taaza karo. markLost: poori list mili thi, jo job usme nahi wo "lost". */
    fun mergeJobs(app: Context, jobs: JSONArray?, markLost: Boolean) {
        synchronized(histLock) {
            val a = histLoad(app)
            val byId = HashMap<String, JSONObject>()
            if (jobs != null) for (i in 0 until jobs.length()) {
                val j = jobs.optJSONObject(i) ?: continue
                byId[j.optString("id")] = j
            }
            var changed = false
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val st = o.optString("state")
                if (st == "done" || st == "error" || st == "cancelled" || st == "lost") continue
                val j = byId[o.optString("id")]
                if (j != null) {
                    o.put("state", j.optString("state", st))
                    o.put("done", j.optLong("bytes_done", 0)).put("total", j.optLong("bytes_total", 0))
                    val res = j.optString("result")
                    if (res.isNotEmpty()) o.put("result", res)
                    val errs = j.optJSONArray("errors")
                    if (errs != null && errs.length() > 0) o.put("err", errs.optString(0))
                    changed = true
                } else if (markLost) {
                    o.put("state", "lost")
                    changed = true
                }
            }
            if (changed) histSave(app, a)
        }
    }

    /** Naya pehle; chalti hui (queued/running) sabse upar. */
    fun history(app: Context): List<SrvRow> {
        val a = synchronized(histLock) { histLoad(app) }
        val out = ArrayList<SrvRow>()
        for (i in a.length() - 1 downTo 0) {
            val o = a.optJSONObject(i) ?: continue
            out.add(
                SrvRow(o.optString("id"), o.optString("name"), o.optString("url"), o.optString("store"), o.optString("path"),
                    o.optLong("t"), o.optString("state"), o.optLong("done"), o.optLong("total"), o.optString("result"), o.optString("err"))
            )
        }
        return out.sortedBy { if (it.active) 0 else 1 }
    }

    fun histClearFinished(app: Context) {
        synchronized(histLock) {
            val a = histLoad(app)
            val keep = JSONArray()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val st = o.optString("state")
                if (st == "queued" || st == "running") keep.put(o)
            }
            histSave(app, keep)
        }
    }

    fun histRemove(app: Context, id: String) {
        synchronized(histLock) {
            val a = histLoad(app)
            val keep = JSONArray()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (o.optString("id") != id) keep.put(o)
            }
            histSave(app, keep)
        }
    }

    /** Server se poori job-list lao aur record taaza karo. [cb] background thread par; null = theek, warna error text. */
    fun refreshServer(ctx: Context, cb: (String?) -> Unit) {
        val app = ctx.applicationContext
        net.execute {
            var err: String? = null
            try {
                val req = Request.Builder().url(xferBase(app, store(app)) + "list").build()
                client(app).newCall(req).execute().use { r ->
                    val txt = r.body?.string() ?: ""
                    if (r.code == 401) err = "Username / password galat"
                    else if (!r.isSuccessful) err = "Server: HTTP " + r.code
                    else mergeJobs(app, JSONObject(txt).optJSONArray("jobs"), true)
                }
            } catch (e: Throwable) {
                err = "Server se judne me dikkat: " + (e.message ?: e.javaClass.simpleName)
            }
            cb(err)
        }
    }

    fun cancelServer(ctx: Context, id: String, cb: (String) -> Unit) {
        val app = ctx.applicationContext
        net.execute {
            val msg = try {
                val req = Request.Builder().url(xferBase(app, store(app)) + "cancel?id=" + Uri.encode(id))
                    .post(ByteArray(0).toRequestBody(null)).build()
                client(app).newCall(req).execute().use { r ->
                    if (r.isSuccessful) "Server par cancel bhej diya" else "Cancel nahi hua (HTTP " + r.code + ")"
                }
            } catch (e: Throwable) { "Cancel nahi hua: " + (e.message ?: "") }
            cb(msg)
        }
    }

    private const val PROPFIND_SIZE =
        "<?xml version=\"1.0\" encoding=\"utf-8\"?><d:propfind xmlns:d=\"DAV:\"><d:prop><d:getcontentlength/></d:prop></d:propfind>"

    /** Server ki WebDAV se dekho ki file sach me wahan hai (aur kitni badi). [cb] background thread par. */
    fun verifyServerFile(ctx: Context, row: SrvRow, cb: (String) -> Unit) {
        val app = ctx.applicationContext
        net.execute {
            val msg = try {
                val res = row.result
                val st = res.substringBefore(":/")
                val p = res.substringAfter(":/", "")
                if (st != "aic" && st != "hf" || p.isEmpty()) {
                    "Server ne file ka path nahi diya"
                } else {
                    val sb = StringBuilder(root(app, st))
                    for (seg in p.split('/').filter { it.isNotEmpty() }) sb.append(Uri.encode(seg)).append('/')
                    val url = sb.toString().trimEnd('/')
                    val req = Request.Builder().url(url)
                        .method("PROPFIND", PROPFIND_SIZE.toRequestBody("application/xml; charset=utf-8".toMediaType()))
                        .header("Depth", "0").build()
                    client(app).newCall(req).execute().use { r ->
                        val txt = r.body?.string() ?: ""
                        when {
                            r.code == 404 -> "❌ Server par ye file nahi mili"
                            r.code == 401 -> "Username / password galat"
                            !r.isSuccessful -> "Server: HTTP " + r.code
                            else -> {
                                val m = Regex("getcontentlength[^>]*>\\s*(\\d+)").find(txt)
                                "✅ Server par file hai" + (if (m != null) " · " + DlFmt.size(m.groupValues[1].toLong()) else "")
                            }
                        }
                    }
                }
            } catch (e: Throwable) { "Check nahi ho paya: " + (e.message ?: "") }
            cb(msg)
        }
    }

    private class HttpErr(val code: Int, msg: String) : IOException(msg)

    private fun postDl(app: Context, store: String, path: String, spec: DlSpec, kind: String, height: Int = 0): String {
        val body = JSONObject()
            .put("url", spec.url).put("name", spec.name).put("cookie", spec.cookie)
            .put("ua", spec.ua).put("referer", spec.referer).put("kind", kind)
            .put("on_conflict", "rename")
            .put("dest", JSONObject().put("store", store).put("path", path))
        if (height < 0) body.put("audio", true) else if (height > 0) body.put("height", height)
        val req = Request.Builder().url(xferBase(app, store) + "dl").post(jsonBody(body)).build()
        client(app).newCall(req).execute().use { r ->
            val txt = r.body?.string() ?: ""
            if (r.code == 401) throw HttpErr(401, "Username / password galat")
            if (!r.isSuccessful) {
                val m = try { JSONObject(txt).optString("error") } catch (e: Exception) { "" }
                throw HttpErr(r.code, if (m.isNotEmpty()) m else "HTTP ${r.code}")
            }
            val id = JSONObject(txt).optString("id")
            if (id.isEmpty()) throw IOException("server ne id nahi di")
            return id
        }
    }

    /**
     * Kai video-page links ek saath (yt-dlp mode). Server ki queue bhari ho (HTTP 429) to 10 sec ruk ke dobara.
     * Phone par fallback NAHI (page link phone se download nahi ho sakta). Aakhir me summary toast.
     */
    fun sendBulk(ctx: Context, specs: List<DlSpec>, height: Int = 0) {
        val app = ctx.applicationContext
        val store = store(app)
        val path = path(app)
        net.execute {
            val ids = ArrayList<String>()
            val nameOf = HashMap<String, String>()
            var rejected = 0
            var lastErr = ""
            DlEngine.toast("☁ " + specs.size + " video server ko bhej rahe hain (" + qualityName(height) + ")…")
            for (spec in specs) {
                var tries = 0
                while (true) {
                    try {
                        val id = postDl(app, store, path, spec, "ytdlp", height)
                        ids.add(id); nameOf[id] = spec.name
                        histAdd(app, id, spec.name, spec.url, store, path)
                        break
                    } catch (e: HttpErr) {
                        if (e.code == 429 && ++tries <= 360) {
                            try { Thread.sleep(10_000) } catch (x: InterruptedException) { return@execute }
                            continue
                        }
                        rejected++; lastErr = e.message ?: ""
                        if (e.code == 401) { DlEngine.toast("☁ " + lastErr); return@execute }
                        break
                    } catch (e: Throwable) {
                        rejected++; lastErr = e.message ?: e.javaClass.simpleName
                        break
                    }
                }
            }
            if (ids.isEmpty()) {
                DlEngine.toast("☁ Server ne koi video nahi liya: $lastErr")
                return@execute
            }
            DlEngine.toast("☁ " + ids.size + " video server ki queue me" + (if (rejected > 0) " ($rejected nahi gaye)" else "") + ". Ho jane par batayenge.")
            val want = HashSet(ids)
            var reported = 0
            var bad = 0
            val end = System.currentTimeMillis() + 12L * 3600 * 1000
            while (System.currentTimeMillis() < end) {
                try { Thread.sleep(10_000) } catch (e: InterruptedException) { return@execute }
                try {
                    val req = Request.Builder().url(xferBase(app, store) + "list").build()
                    client(app).newCall(req).execute().use { r ->
                        val txt = r.body?.string() ?: ""
                        if (!r.isSuccessful) { bad++; return@use }
                        bad = 0
                        val jobs = JSONObject(txt).optJSONArray("jobs") ?: return@use
                        mergeJobs(app, jobs, false)
                        var done = 0; var failed = 0; var removed = 0; var open = 0
                        var firstFail = ""
                        for (i in 0 until jobs.length()) {
                            val j = jobs.optJSONObject(i) ?: continue
                            val id = j.optString("id")
                            if (id !in want) continue
                            when (j.optString("state")) {
                                "done" -> done++
                                "error", "cancelled" -> {
                                    val errs = j.optJSONArray("errors")
                                    val why = if (errs != null && errs.length() > 0) errs.optString(0) else j.optString("state")
                                    if (why.startsWith("[removed]")) {
                                        removed++          // site se hata di gayi / private / country-lock: skip, agle par
                                    } else {
                                        failed++
                                        if (firstFail.isEmpty()) firstFail = (nameOf[id] ?: "") + ": " + why
                                    }
                                }
                                else -> open++
                            }
                        }
                        val seen = done + failed + removed
                        if (open == 0 && seen >= want.size - 0) {
                            DlEngine.toast("☁ Server par: $done ho gaye" +
                                (if (removed > 0) ", $removed site se hata di gayi (skip)" else "") +
                                (if (failed > 0) ", $failed fail ($firstFail)" else ""))
                            return@execute
                        }
                        if (done >= reported + 5) { reported = done; DlEngine.toast("☁ $done / ${want.size} ho gaye") }
                    }
                } catch (e: Throwable) { bad++ }
                if (bad >= 30) return@execute
            }
        }
    }

    private fun pollDirect(app: Context, store: String, id: String, name: String, onFail: () -> Unit) {
        var bad = 0
        val end = System.currentTimeMillis() + 12L * 3600 * 1000
        while (System.currentTimeMillis() < end) {
            try { Thread.sleep(3000) } catch (e: InterruptedException) { return }
            try {
                val req = Request.Builder().url(xferBase(app, store) + "status?id=" + Uri.encode(id)).build()
                client(app).newCall(req).execute().use { r ->
                    val txt = r.body?.string() ?: ""
                    if (r.code == 404) { bad = 99; return@use }        // server restart: job chali gayi
                    if (!r.isSuccessful) { bad++; return@use }
                    bad = 0
                    val j = JSONObject(txt)
                    mergeJobs(app, JSONArray().put(j), false)
                    when (j.optString("state")) {
                        "done" -> {
                            val res = j.optString("result")
                            DlEngine.toast("☁ Server par ho gaya: " + (if (res.isNotEmpty()) res else name))
                            return
                        }
                        "cancelled" -> return
                        "error" -> {
                            val errs = j.optJSONArray("errors")
                            val m = if (errs != null && errs.length() > 0) errs.optString(0) else "error"
                            if (m.startsWith("[removed]")) {
                                DlEngine.toast("☁ Video site se hata di gayi ya available nahi: $name")
                            } else {
                                DlEngine.toast("☁ Server se download nahi hua ($m), phone par try kar rahe hain")
                                onFail()
                            }
                            return
                        }
                    }
                }
            } catch (e: Throwable) { bad++ }
            if (bad >= 20) return   // net gaya / server restart: job server par chalti rahegi, bas ham khabar nahi de paye
        }
    }

    // ── folder list (picker ke liye) ──────────────────────────────────────
    private const val PROPFIND =
        "<?xml version=\"1.0\" encoding=\"utf-8\"?><d:propfind xmlns:d=\"DAV:\"><d:prop><d:resourcetype/></d:prop></d:propfind>"

    /** Sirf subfolders ke naam. Error par IOException. */
    fun listFolders(ctx: Context, store: String, path: String): List<String> {
        val base = urlOf(ctx, store, path)
        val req = Request.Builder().url(base)
            .method("PROPFIND", PROPFIND.toRequestBody("application/xml; charset=utf-8".toMediaType()))
            .header("Depth", "1").build()
        client(ctx).newCall(req).execute().use { r ->
            if (r.code == 401) throw IOException("Username / password galat")
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val stream = r.body?.byteStream() ?: throw IOException("khaali jawab")
            val p = Xml.newPullParser()
            p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
            p.setInput(stream, null)
            val out = ArrayList<String>()
            var href = ""; var isDir = false; var idx = -1
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "response" -> { href = ""; isDir = false; idx++ }
                        "href" -> href = p.nextText().trim()
                        "collection" -> isDir = true
                    }
                } else if (ev == XmlPullParser.END_TAG && p.name == "response" && idx > 0 && href.isNotEmpty() && isDir) {
                    val name = Uri.decode(href.trimEnd('/').substringAfterLast('/'))
                    if (name.isNotEmpty()) out.add(name)
                }
                ev = p.next()
            }
            return out.sortedWith(String.CASE_INSENSITIVE_ORDER)
        }
    }

    fun mkdir(ctx: Context, store: String, path: String) {
        val req = Request.Builder().url(urlOf(ctx, store, path)).method("MKCOL", null).build()
        client(ctx).newCall(req).execute().use { r ->
            if (r.code == 401) throw IOException("Username / password galat")
            if (!r.isSuccessful && r.code != 405) throw IOException("HTTP ${r.code}")   // 405 = pehle se hai
        }
    }

    private fun ensureDirs(ctx: Context, store: String, path: String) {
        var cur = ""
        for (seg in path.trim('/').split('/').filter { it.isNotEmpty() }) {
            cur += "/$seg"
            mkdir(ctx, store, cur)
        }
    }

    // ── upload ────────────────────────────────────────────────────────────
    private class FileBody(
        private val ctx: Context, private val src: String, private val len: Long, private val mime: String
    ) : RequestBody() {
        override fun contentType(): MediaType? = mime.toMediaTypeOrNull()
        override fun contentLength(): Long = len
        override fun writeTo(sink: BufferedSink) {
            val ins = if (src.startsWith("content://")) ctx.contentResolver.openInputStream(Uri.parse(src))
            else File(src).inputStream()
            (ins ?: throw IOException("file nahi khuli")).use { sink.writeAll(it.source()) }
        }
    }

    private fun sizeOf(ctx: Context, src: String): Long {
        return try {
            if (src.startsWith("content://"))
                ctx.contentResolver.openFileDescriptor(Uri.parse(src), "r")?.use { it.statSize } ?: -1L
            else File(src).length()
        } catch (e: Exception) { -1L }
    }

    /** DlEngine ne download poora hone par bulaya. Server band ho to kuch nahi karta. */
    fun onSaved(ctx: Context, t: DlTask) {
        if (!enabled(ctx) || t.savedUri.isEmpty()) return
        val app = ctx.applicationContext
        val src = t.savedUri
        val name = t.name
        val mime = t.mime.ifEmpty { "application/octet-stream" }
        val store = store(app)
        val path = path(app)
        io.execute {
            try {
                DlEngine.toast("☁ Server par bhej rahe hain: $name")
                ensureDirs(app, store, path)
                val len = sizeOf(app, src)
                val url = urlOf(app, store, path) + Uri.encode(name)
                val req = Request.Builder().url(url).put(FileBody(app, src, len, mime)).build()
                client(app).newCall(req).execute().use { r ->
                    if (r.code == 401) throw IOException("Username / password galat")
                    if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                }
                val label = (if (store == "hf") "HF" else "AIC") + ":" + (if (path.startsWith("/")) path else "/$path")
                if (DlSettings.getBool(app, K_DELETE, true)) {
                    try {
                        if (src.startsWith("content://")) app.contentResolver.delete(Uri.parse(src), null, null)
                        else File(src).delete()
                    } catch (e: Exception) { }
                    t.savedUri = ""
                }
                t.savedPath = "☁ $label/$name"
                DlEngine.toast("☁ Server par ho gaya: $label/$name")
            } catch (e: Throwable) {
                DlEngine.toast("☁ Server upload fail (file phone par safe hai): " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }
}

object Dav {
    fun slash(u: String): String = if (u.endsWith("/")) u else "$u/"
}
