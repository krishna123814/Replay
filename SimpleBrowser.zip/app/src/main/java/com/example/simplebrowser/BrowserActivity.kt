package com.example.simplebrowser

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class BrowserActivity : AppCompatActivity() {


    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var btnBack: Button
    private lateinit var btnForward: Button

    // <input type=file> ka callback
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val filePicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            uploadCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            )
            uploadCallback = null
        }

    private fun launchPicker(i: Intent) {
        try {
            filePicker.launch(i)
        } catch (e: Exception) {
            uploadCallback?.onReceiveValue(null)
            uploadCallback = null
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full-screen: status bar bhi cover, notch ke neeche bhi draw
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        setContentView(R.layout.activity_browser)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.browserRoot)) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        hideStatusBar()

        web = findViewById(R.id.web)
        urlBar = findViewById(R.id.urlBar)
        progress = findViewById(R.id.progress)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = false
            allowContentAccess = true
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            userAgentString = PopupLogin.cleanUa(this@BrowserActivity)
        }
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        // file download: Abhi / Schedule dialog
        web.addJavascriptInterface(BlobDl.Bridge(applicationContext), BlobDl.BRIDGE_NAME)
        web.addJavascriptInterface(ShotBridge.Bridge(applicationContext, web), ShotBridge.NAME)
        web.addJavascriptInterface(VideoDetect.Bridge(this, false), VideoDetect.BRIDGE_NAME)
        web.setDownloadListener { dlUrl, ua, cd, mime, len ->
            Downloader.offer(this, false, dlUrl, ua, cd, mime, len, web.url, web)
        }

        web.webViewClient = object : WebViewClient() {
                // 🔒 Server ab password ke peeche hai (nginx basic auth): Lion ka saved login (Session) apne server ke liye
                // WebView ko de do. Dusri sites par kuch nahi karta.
                override fun onReceivedHttpAuthRequest(view: WebView?, handler: android.webkit.HttpAuthHandler?, host: String?, realm: String?) {
                    val S = com.example.simplebrowser.files.Session
                    val a = applicationContext
                    if (!S.hasCreds()) S.load(a)
                    val sh = try { android.net.Uri.parse(S.baseUrl).host } catch (e: Exception) { null }
                    if (handler != null && host != null && host == sh && S.hasCreds()) handler.proceed(S.user, S.pass)
                    else super.onReceivedHttpAuthRequest(view, handler, host, realm)
                }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!urlBar.hasFocus()) urlBar.setText(url)
                progress.visibility = View.VISIBLE
                VideoDetect.inject(view)
            }

            override fun onPageFinished(view: WebView, url: String) {
                progress.visibility = View.GONE
                VideoDetect.inject(view)
                updateNavButtons()
                History.touchTitle(applicationContext, url, view.title)
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                History.record(applicationContext, url, view.title)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val scheme = request.url.scheme ?: return false
                if (scheme == "http" || scheme == "https") return false
                // tel:, mailto:, intent: jaise links ko dusri app me kholo
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (_: Exception) {
                }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
            }

            override fun onCreateWindow(
                view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?
            ): Boolean = PopupLogin.open(this@BrowserActivity, false, resultMsg)

            override fun onReceivedTitle(view: WebView, title: String?) {
                super.onReceivedTitle(view, title)
                History.touchTitle(applicationContext, view.url, title)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (callback == null || params == null) return false
                uploadCallback?.onReceiveValue(null)
                uploadCallback = callback
                return try {
                    val picker = params.createIntent()
                    LionPicker.ask(
                        this@BrowserActivity,
                        onFiles = { launchPicker(LionPicker.filesIntent(this@BrowserActivity, picker)) },
                        onSystem = { launchPicker(Intent.createChooser(picker, "File chuniye")) },
                        onCancel = { uploadCallback?.onReceiveValue(null); uploadCallback = null }
                    )
                    true
                } catch (e: Exception) {
                    uploadCallback = null
                    false
                }
            }
        }

        btnBack.setOnClickListener { if (web.canGoBack()) web.goBack() }
        btnForward.setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<Button>(R.id.btnReload).setOnClickListener { web.reload() }
        // Reload button ko dabaye rakho: History / Download queue / Download settings (screen par kuch naya nahi)
        findViewById<Button>(R.id.btnReload).setOnLongClickListener {
            showMoreMenu()
            true
        }
        findViewById<Button>(R.id.btnGo).setOnClickListener { goToInput() }
        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                goToInput()
                true
            } else false
        }

        // Phone ka back button: pehle page me peeche, nahi to app band
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) {
                    web.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        if (savedInstanceState == null) {
            web.loadUrl(AppConfig.BROWSER_HOME)
        } else {
            web.restoreState(savedInstanceState)
        }
        updateNavButtons()
    }

    private fun showMoreMenu() {
        val items = arrayOf("📜 History", "📥 Downloads (phone + server)", "⚡ Download settings")
        android.app.AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> History.show(this, false) { u -> web.loadUrl(u) }
                    1 -> DlUi.queue(this, false)
                    2 -> DlUi.settings(this, false)
                }
            }
            .setNegativeButton("Band", null)
            .show()
    }

    private fun hideStatusBar() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.statusBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideStatusBar()
    }

    private fun goToInput() {
        web.loadUrl(toUrl(urlBar.text.toString()))
        urlBar.clearFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    /** Typed text ko URL ya Google search me badalta hai. */
    private fun toUrl(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return AppConfig.BROWSER_HOME
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        val ipPort = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")
        if (ipPort.matches(t)) return "http://$t"          // IP:port aam taur par http hota hai
        val looksLikeHost = !t.contains(" ") && (t.contains(".") || t.startsWith("localhost"))
        return if (looksLikeHost) "https://$t"
        else "https://www.google.com/search?q=" + Uri.encode(t)
    }

    private fun updateNavButtons() {
        btnBack.alpha = if (web.canGoBack()) 1f else 0.35f
        btnForward.alpha = if (web.canGoForward()) 1f else 0.35f
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
